# Jujutsu Pixel Battle Online — bản khởi đầu

## Triển khai Render
1. Giải nén ZIP và đưa toàn bộ thư mục này lên một GitHub repository.
2. Trên Render chọn **New + → Web Service**, kết nối repository.
3. Build Command: `npm install`; Start Command: `npm start`; Runtime: Node. (Có thể dùng `render.yaml` nếu tạo Blueprint.)
4. Đợi deploy trạng thái **Live** rồi mở URL Render. Endpoint `/health` phải trả về JSON có `"ok": true`.
5. Hai người mở cùng URL: người thứ nhất vào tab 🌐 ONLINE → TẠO PHÒNG; người thứ hai nhập mã 6 chữ số; sau đó nhấn BẮT ĐẦU.

## Lưu ý quan trọng
Đây là bản tích hợp máy chủ đầu tiên: tạo/join phòng qua Internet, báo đủ 2 người, bắt đầu đồng thời, đồng bộ vị trí và chuyển tiếp sự kiện sát thương cơ bản. Các chiêu có hiệu ứng phức tạp, thức thần, lãnh địa và trạng thái va chạm chưa được đồng bộ hoàn chỉnh/đồng bộ-authoritative; cần vòng phát triển tiếp theo để đạt multiplayer ổn định. Không nên coi đây là bản thi đấu hoàn chỉnh.

Nếu deploy vẫn Failed, mở mục **Logs** của Render và xử lý lỗi đầu tiên hiển thị; file này dùng Node.js 18+ và cài dependency tự động.
