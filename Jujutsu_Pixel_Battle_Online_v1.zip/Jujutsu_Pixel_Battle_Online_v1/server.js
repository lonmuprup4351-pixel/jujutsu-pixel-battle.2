const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true }, pingInterval: 25000, pingTimeout: 20000 });
const rooms = new Map();
app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_req, res) => res.json({ ok: true, service: 'jpb-online', rooms: rooms.size }));
function cleanRoom(code) { const r = rooms.get(code); if (r && r.players.size === 0) rooms.delete(code); }
function roomPayload(code) { const r = rooms.get(code); return { code, players: r ? r.players.size : 0 }; }
io.on('connection', socket => {
  socket.on('create-room', data => {
    let code; do { code = String(Math.floor(100000 + Math.random() * 900000)); } while (rooms.has(code));
    rooms.set(code, { players: new Map([[socket.id, { role: 1, kind: data?.kind || 'gojo' }]]), started: false });
    socket.join(code); socket.data.room = code; socket.data.role = 1;
    socket.emit('room-created', { code, players: 1, role: 1 });
    io.to(code).emit('room-update', roomPayload(code));
  });
  socket.on('join-room', data => {
    const code = String(data?.code || ''); const room = rooms.get(code);
    if (!/^\d{6}$/.test(code) || !room) return socket.emit('room-error', 'Không tìm thấy phòng. Kiểm tra lại mã phòng.');
    if (room.players.size >= 2) return socket.emit('room-error', 'Phòng đã đủ 2 người.');
    if (room.players.has(socket.id)) return;
    room.players.set(socket.id, { role: 2, kind: data?.kind || 'sukuna' });
    socket.join(code); socket.data.room = code; socket.data.role = 2;
    socket.emit('room-joined', { code, players: room.players.size, role: 2 });
    io.to(code).emit('room-update', roomPayload(code));
  });
  socket.on('start-game', data => {
    const code = String(data?.code || ''); const room = rooms.get(code);
    if (!room || !room.players.has(socket.id)) return;
    if (room.players.size !== 2) return socket.emit('room-error', 'Cần đủ 2 người trong phòng.');
    room.started = true; io.to(code).emit('game-start');
  });
  socket.on('player-state', data => {
    const code = String(data?.code || ''); const room = rooms.get(code);
    if (!room || !room.players.has(socket.id) || !room.started) return;
    const s = data?.state || {};
    const safe = { x: clampNum(s.x, -10000, 10000), y: clampNum(s.y, -10000, 10000), hp: clampNum(s.hp, 0, 2000), max: clampNum(s.max, 1, 2000), energy: clampNum(s.energy, 0, 1000), face: s.face < 0 ? -1 : 1, kind: ['gojo','sukuna','megumi','mahoraga'].includes(s.kind) ? s.kind : 'gojo' };
    socket.to(code).emit('player-state', safe);
  });
  socket.on('player-hit', data => {
    const code = String(data?.code || ''); const room = rooms.get(code);
    if (!room || !room.players.has(socket.id) || !room.started) return;
    socket.to(code).emit('player-hit', { damage: clampNum(data?.damage, 0, 100) });
  });
  socket.on('leave-room', data => { const code = String(data?.code || socket.data.room || ''); leaveRoom(socket, code); });
  socket.on('disconnect', () => { if (socket.data.room) leaveRoom(socket, socket.data.room); });
});
function clampNum(v, min, max) { v = Number(v); return Number.isFinite(v) ? Math.max(min, Math.min(max, v)) : min; }
function leaveRoom(socket, code) { const room = rooms.get(code); if (!room) return; room.players.delete(socket.id); socket.leave(code); socket.data.room = null; socket.to(code).emit('opponent-left'); io.to(code).emit('room-update', roomPayload(code)); cleanRoom(code); }
const port = process.env.PORT || 3000;
server.listen(port, '0.0.0.0', () => console.log(`Jujutsu Pixel Battle online server listening on ${port}`));
